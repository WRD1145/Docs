import{m as s}from"./mermaid.esm.min-BYPvxEGR.js";var t,e=(t=class{constructor(i){this.init=i,this.records=this.init()}reset(){this.records=this.init()}},s(t,"ImperativeState"),t);export{e as s};
